﻿using UnityEngine;
using System.Collections;

public class Test : MonoBehaviour {

	// Use this for initialization
	void Start () {
        //BaseCharacter Cecil = new Limca();
        //Debug.Log("Name : "+Cecil.Name);
        //Debug.Log("HP : "+Cecil.Hp);
        //if(Cecil.CharacterUnitName == BaseCharacter.CharacterUnit.LIMCA)
        //{
        //    Debug.Log("I'm really Limca");
        //}
        //else
        //{
        //    Debug.Log("I'm not actually Limca");
        //}
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
